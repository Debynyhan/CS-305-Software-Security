/****************************************
* 
* CS-305 Project 2                     
* SslServerApplication.java            
* 
* Debynyhan Banks
* Southern New Hampshire University
* CS-305 Software Security
* Professor Sarah North
* 
* 
* ***************************************/

package com.snhu.sslserver;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.Base64;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;




@SpringBootApplication
@RestController
public class SslServerApplication {
	
	// Define constants to be used throughout the application
	private static final String CHARSET = StandardCharsets.UTF_8.name();
	private static final String HASH_ALGORITHM = "SHA-256";
	private static final int SALT_LENGTH = 32;
	
	// Entry point of the application
	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}
	
	// Handle requests to the root URL of the server
	@RequestMapping("/")
	public String getChecksum() {
		
		
		try {
			
			// Data to be hashed
			String name = "Debynyhan Banks";
			String data = "Hello World, CheckSum from " + name;
			
			// Generate a salt value
			byte[] salt = generateSalt(SALT_LENGTH);
			
			// Generate a hash of the data with the salt value
			byte[] hash = generateHash(data, salt);
			
			// Convert the salt and hash to base64-encoded string representations
			String saltString = Base64.getEncoder().encodeToString(salt);
			String hashString = Base64.getEncoder().encodeToString(hash);

			// Return a string with the original data, salt, and hash
			return String.format("<p>student name: %s</p><p>salt value: %s</p><p>hash: %s</p><p>algorithm used: %s</p>", 
					name, saltString, hashString, HASH_ALGORITHM);
			
		} catch (NoSuchAlgorithmException e) {
			
			// If the hash algorithm is not available, return an error message
			return "<p>Internal server error.</p>";
			
		} catch (Exception e) {
			
			// If an exception is thrown during encryption, return an error message
			return "<p>Internal server error.</p>";
		}
	}
	
	// Generate a random salt value
	private static byte[] generateSalt(int length) {
		SecureRandom random = new SecureRandom();
		byte[] salt = new byte[length];
		random.nextBytes(salt);
		return salt;
	}
	
	// Generate a hash of the input data using the SHA-256 algorithm and a salt value
	private static byte[] generateHash(String data, byte[] salt) throws NoSuchAlgorithmException, UnsupportedEncodingException {
		MessageDigest digest = MessageDigest.getInstance(HASH_ALGORITHM);
		digest.update(salt);
		byte[] hash = digest.digest(data.getBytes(CHARSET));
		return hash;
	}
}